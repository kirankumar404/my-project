import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useToast } from '../context/ToastContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { cart } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [search, setSearch] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);

  const handleSearch = (e) => {
    e.preventDefault();
    if (search.trim()) {
      navigate(`/products?search=${encodeURIComponent(search.trim())}`);
      setSearch('');
    }
  };

  const handleLogout = async () => {
    await logout();
    toast('Logged out successfully', 'info');
    navigate('/');
  };

  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 1000,
      background: 'rgba(5,8,16,0.95)',
      backdropFilter: 'blur(20px)',
      borderBottom: '1px solid rgba(0,212,255,0.12)',
      padding: '0 1.5rem',
    }}>
      <div className="container" style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', height: '64px' }}>
        {/* Logo */}
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexShrink: 0 }}>
          <span style={{
            fontFamily: 'var(--font-display)', fontSize: '1.2rem', fontWeight: '900',
            color: 'var(--cyan)', letterSpacing: '0.1em',
            textShadow: '0 0 20px rgba(0,212,255,0.5)',
          }}>ELECTRO<span style={{ color: 'var(--text)' }}>ZONE</span></span>
        </Link>

        {/* Nav links */}
        <div style={{ display: 'flex', gap: '0.25rem', flexShrink: 0 }}>
          {[['/', 'Home'], ['/products', 'Products'], ['/products?featured=true', 'Featured'], ['/products?deals=true', 'Deals']].map(([href, label]) => (
            <Link key={href} to={href} style={{
              padding: '0.4rem 0.8rem', borderRadius: '6px',
              fontSize: '0.82rem', fontWeight: '500',
              color: location.pathname === href ? 'var(--cyan)' : 'var(--text2)',
              background: location.pathname === href ? 'var(--cyan-dim)' : 'transparent',
              transition: 'all var(--transition)',
            }}
              onMouseEnter={e => { if (location.pathname !== href) e.target.style.color = 'var(--cyan)'; }}
              onMouseLeave={e => { if (location.pathname !== href) e.target.style.color = 'var(--text2)'; }}
            >{label}</Link>
          ))}
        </div>

        {/* Search */}
        <form onSubmit={handleSearch} style={{ flex: 1, maxWidth: '400px' }}>
          <div style={{ position: 'relative' }}>
            <input
              type="text" placeholder="Search electronics..."
              value={search} onChange={e => setSearch(e.target.value)}
              className="input"
              style={{ paddingRight: '2.5rem', height: '38px', fontSize: '0.85rem' }}
            />
            <button type="submit" style={{
              position: 'absolute', right: '8px', top: '50%', transform: 'translateY(-50%)',
              background: 'none', color: 'var(--text3)', fontSize: '0.9rem', padding: '4px',
            }}>⌕</button>
          </div>
        </form>

        {/* Right actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginLeft: 'auto' }}>
          {user ? (
            <>
              <Link to="/wishlist" title="Wishlist" style={{ color: 'var(--text2)', fontSize: '1.2rem', transition: 'color var(--transition)' }}
                onMouseEnter={e => e.target.style.color = 'var(--cyan)'}
                onMouseLeave={e => e.target.style.color = 'var(--text2)'}
              >♡</Link>
              <Link to="/cart" style={{ position: 'relative', color: 'var(--text2)', fontSize: '1.2rem', transition: 'color var(--transition)' }}
                onMouseEnter={e => e.target.style.color = 'var(--cyan)'}
                onMouseLeave={e => e.target.style.color = 'var(--text2)'}
              >
                🛒
                {cart.total_items > 0 && (
                  <span style={{
                    position: 'absolute', top: '-6px', right: '-8px',
                    background: 'var(--cyan)', color: '#000',
                    borderRadius: '50%', width: '18px', height: '18px',
                    fontSize: '0.65rem', fontWeight: '700',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>{cart.total_items}</span>
                )}
              </Link>
              <div style={{ position: 'relative' }}>
                <button
                  onClick={() => setMenuOpen(!menuOpen)}
                  style={{
                    background: 'var(--surface)', border: '1px solid var(--border)',
                    borderRadius: '8px', padding: '0.4rem 0.8rem',
                    color: 'var(--text)', fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: '0.4rem',
                  }}
                >
                  <span style={{ color: 'var(--cyan)' }}>◈</span>
                  {user.first_name}
                </button>
                {menuOpen && (
                  <div style={{
                    position: 'absolute', right: 0, top: 'calc(100% + 8px)',
                    background: 'var(--surface)', border: '1px solid var(--border2)',
                    borderRadius: '10px', padding: '0.5rem', minWidth: '160px', zIndex: 100,
                  }}>
                    {[['profile', '◈ Profile'], ['orders', '📦 Orders']].map(([path, label]) => (
                      <Link key={path} to={`/${path}`} onClick={() => setMenuOpen(false)}
                        style={{ display: 'block', padding: '0.6rem 0.8rem', borderRadius: '6px', fontSize: '0.85rem', color: 'var(--text2)', transition: 'all var(--transition)' }}
                        onMouseEnter={e => { e.target.style.background = 'var(--cyan-dim)'; e.target.style.color = 'var(--cyan)'; }}
                        onMouseLeave={e => { e.target.style.background = 'transparent'; e.target.style.color = 'var(--text2)'; }}
                      >{label}</Link>
                    ))}
                    <hr style={{ border: 'none', borderTop: '1px solid var(--border)', margin: '0.4rem 0' }} />
                    <button onClick={handleLogout}
                      style={{ width: '100%', background: 'none', textAlign: 'left', padding: '0.6rem 0.8rem', borderRadius: '6px', fontSize: '0.85rem', color: 'var(--red)', transition: 'all var(--transition)' }}
                      onMouseEnter={e => e.target.style.background = 'rgba(255,71,87,0.1)'}
                      onMouseLeave={e => e.target.style.background = 'transparent'}
                    >⏻ Logout</button>
                  </div>
                )}
              </div>
            </>
          ) : (
            <>
              <Link to="/login" className="btn btn-ghost" style={{ padding: '0.5rem 1.2rem', fontSize: '0.82rem' }}>Login</Link>
              <Link to="/register" className="btn btn-primary" style={{ padding: '0.5rem 1.2rem', fontSize: '0.82rem' }}>Sign Up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
