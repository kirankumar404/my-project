from django.urls import path
from . import views

urlpatterns = [
    path('', views.get_cart, name='cart'),
    path('add/', views.add_to_cart, name='cart-add'),
    path('item/<int:item_id>/update/', views.update_cart_item, name='cart-update'),
    path('item/<int:item_id>/remove/', views.remove_cart_item, name='cart-remove'),
    path('clear/', views.clear_cart, name='cart-clear'),
]
