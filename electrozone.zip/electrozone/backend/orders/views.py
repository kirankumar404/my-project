from rest_framework import serializers, viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db import transaction
from .models import Order, OrderItem
from cart.models import Cart


# ── Serializers ──

class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = ['id', 'product_name', 'product_image', 'unit_price', 'quantity', 'line_total']


class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    order_id_short = serializers.SerializerMethodField()

    class Meta:
        model = Order
        fields = ['id', 'order_id', 'order_id_short', 'status', 'payment_method',
                  'payment_status', 'shipping_name', 'shipping_email', 'shipping_phone',
                  'shipping_address', 'shipping_city', 'shipping_state', 'shipping_pincode',
                  'subtotal', 'tax', 'shipping_charge', 'total', 'notes',
                  'items', 'created_at']

    def get_order_id_short(self, obj):
        return str(obj.order_id)[:8].upper()


class PlaceOrderSerializer(serializers.Serializer):
    shipping_name = serializers.CharField(max_length=100)
    shipping_email = serializers.EmailField()
    shipping_phone = serializers.CharField(max_length=15)
    shipping_address = serializers.CharField()
    shipping_city = serializers.CharField(max_length=100)
    shipping_state = serializers.CharField(max_length=100)
    shipping_pincode = serializers.CharField(max_length=10)
    payment_method = serializers.ChoiceField(choices=['cod', 'upi', 'card'])
    notes = serializers.CharField(required=False, allow_blank=True)


# ── Views ──

class OrderViewSet(viewsets.ReadOnlyModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = OrderSerializer

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user).prefetch_related('items')

    @action(detail=False, methods=['post'])
    def place(self, request):
        serializer = PlaceOrderSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=400)

        try:
            cart = Cart.objects.get(user=request.user)
        except Cart.DoesNotExist:
            return Response({'error': 'Cart is empty'}, status=400)

        cart_items = cart.items.select_related('product').all()
        if not cart_items.exists():
            return Response({'error': 'Cart is empty'}, status=400)

        # Validate stock
        for item in cart_items:
            if item.product.stock < item.quantity:
                return Response({
                    'error': f'Insufficient stock for {item.product.name}'
                }, status=400)

        data = serializer.validated_data
        subtotal = cart.subtotal
        tax = round(subtotal * 0.18, 2)  # 18% GST
        shipping = 0 if subtotal >= 500 else 49
        total = subtotal + tax + shipping

        with transaction.atomic():
            order = Order.objects.create(
                user=request.user,
                subtotal=subtotal,
                tax=tax,
                shipping_charge=shipping,
                total=total,
                **data
            )
            for item in cart_items:
                OrderItem.objects.create(
                    order=order,
                    product=item.product,
                    product_name=item.product.name,
                    product_image=item.product.image_url or '',
                    unit_price=item.product.discounted_price,
                    quantity=item.quantity,
                    line_total=item.line_total,
                )
                # Reduce stock
                item.product.stock -= item.quantity
                item.product.save()

            cart.items.all().delete()

        return Response(OrderSerializer(order).data, status=201)
