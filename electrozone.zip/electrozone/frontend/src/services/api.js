const BASE_URL = 'http://localhost:8000/api';

// ── Token Management ──
export const getToken = () => localStorage.getItem('access_token');
export const getRefresh = () => localStorage.getItem('refresh_token');
export const setTokens = (access, refresh) => {
  localStorage.setItem('access_token', access);
  if (refresh) localStorage.setItem('refresh_token', refresh);
};
export const clearTokens = () => {
  localStorage.removeItem('access_token');
  localStorage.removeItem('refresh_token');
};

// ── Core Fetch ──
async function request(endpoint, options = {}) {
  const token = getToken();
  const headers = { 'Content-Type': 'application/json', ...options.headers };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${BASE_URL}${endpoint}`, { ...options, headers });

  if (res.status === 401) {
    // Try refresh
    const refresh = getRefresh();
    if (refresh) {
      const refreshRes = await fetch(`${BASE_URL}/auth/token/refresh/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh }),
      });
      if (refreshRes.ok) {
        const data = await refreshRes.json();
        setTokens(data.access, data.refresh);
        headers['Authorization'] = `Bearer ${data.access}`;
        const retry = await fetch(`${BASE_URL}${endpoint}`, { ...options, headers });
        return retry.json();
      } else {
        clearTokens();
        window.location.href = '/login';
        return;
      }
    }
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Something went wrong' }));
    throw err;
  }
  if (res.status === 204) return null;
  return res.json();
}

// ── Auth API ──
export const authAPI = {
  register: (data) => request('/auth/register/', { method: 'POST', body: JSON.stringify(data) }),
  login: (data) => request('/auth/login/', { method: 'POST', body: JSON.stringify(data) }),
  logout: (refresh) => request('/auth/logout/', { method: 'POST', body: JSON.stringify({ refresh }) }),
  getProfile: () => request('/auth/profile/'),
  updateProfile: (data) => request('/auth/profile/', { method: 'PATCH', body: JSON.stringify(data) }),
};

// ── Products API ──
export const productsAPI = {
  list: (params = '') => request(`/products/?${params}`),
  detail: (slug) => request(`/products/${slug}/`),
  featured: () => request('/products/featured/'),
  deals: () => request('/products/deals/'),
  categories: () => request('/products/categories/'),
  brands: () => request('/products/brands/'),
  addReview: (slug, data) => request(`/products/${slug}/review/`, { method: 'POST', body: JSON.stringify(data) }),
};

// ── Cart API ──
export const cartAPI = {
  get: () => request('/cart/'),
  add: (product_id, quantity = 1) => request('/cart/add/', { method: 'POST', body: JSON.stringify({ product_id, quantity }) }),
  update: (item_id, quantity) => request(`/cart/item/${item_id}/update/`, { method: 'PATCH', body: JSON.stringify({ quantity }) }),
  remove: (item_id) => request(`/cart/item/${item_id}/remove/`, { method: 'DELETE' }),
  clear: () => request('/cart/clear/', { method: 'DELETE' }),
};

// ── Orders API ──
export const ordersAPI = {
  list: () => request('/orders/'),
  detail: (id) => request(`/orders/${id}/`),
  place: (data) => request('/orders/place/', { method: 'POST', body: JSON.stringify(data) }),
};

// ── Wishlist API ──
export const wishlistAPI = {
  list: () => request('/products/wishlist/'),
  toggle: (product_id) => request('/products/wishlist/', { method: 'POST', body: JSON.stringify({ product_id }) }),
};
