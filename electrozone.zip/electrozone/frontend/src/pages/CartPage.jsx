import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

export default function CartPage() {
  const { cart, updateItem, removeItem, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  if (!user) return (
    <div style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1rem' }}>
      <div style={{ fontSize: '3rem' }}>🛒</div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem' }}>Please Login</div>
      <Link to="/login" className="btn btn-primary">Login to View Cart</Link>
    </div>
  );

  const subtotal = Number(cart.subtotal || 0);
  const tax = Math.round(subtotal * 0.18);
  const shipping = subtotal >= 500 ? 0 : 49;
  const total = subtotal + tax + shipping;

  if (cart.items.length === 0) return (
    <div style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1rem' }}>
      <div style={{ fontSize: '4rem' }}>🛒</div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.5rem' }}>Your cart is empty</div>
      <Link to="/products" className="btn btn-primary">Start Shopping</Link>
    </div>
  );

  return (
    <div style={{ padding: '2.5rem 1.5rem' }}>
      <div className="container">
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--cyan)', letterSpacing: '0.1em', marginBottom: '0.5rem' }}>// SHOPPING CART</div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: '700', marginBottom: '2rem' }}>
          Cart <span style={{ color: 'var(--text3)', fontSize: '1rem' }}>({cart.total_items} items)</span>
        </h1>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '2rem', alignItems: 'start' }}>
          {/* Cart Items */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {cart.items.map(item => (
              <div key={item.id} className="card" style={{ padding: '1.25rem', display: 'flex', gap: '1.25rem', alignItems: 'center' }}>
                <img src={item.product.thumbnail} alt={item.product.name}
                  style={{ width: '80px', height: '80px', objectFit: 'contain', borderRadius: '8px', background: 'var(--bg3)', padding: '0.5rem', flexShrink: 0 }} />
                <div style={{ flex: 1 }}>
                  <Link to={`/product/${item.product.slug}`} style={{ fontWeight: '600', fontSize: '0.95rem', color: 'var(--text)', display: 'block', marginBottom: '0.3rem' }}>
                    {item.product.name}
                  </Link>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--cyan)' }}>
                    ₹{Number(item.product.discounted_price).toLocaleString('en-IN')} each
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', border: '1px solid var(--border)', borderRadius: '8px', overflow: 'hidden' }}>
                    <button onClick={() => updateItem(item.id, item.quantity - 1)}
                      style={{ padding: '0.4rem 0.75rem', background: 'none', color: 'var(--text)', fontSize: '1rem', borderRight: '1px solid var(--border)' }}>−</button>
                    <span style={{ padding: '0.4rem 0.75rem', fontFamily: 'var(--font-mono)', fontSize: '0.85rem', minWidth: '40px', textAlign: 'center' }}>{item.quantity}</span>
                    <button onClick={() => updateItem(item.id, item.quantity + 1)}
                      style={{ padding: '0.4rem 0.75rem', background: 'none', color: 'var(--text)', fontSize: '1rem', borderLeft: '1px solid var(--border)' }}>+</button>
                  </div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.95rem', fontWeight: '700', color: 'var(--text)', minWidth: '90px', textAlign: 'right' }}>
                    ₹{Number(item.line_total).toLocaleString('en-IN')}
                  </div>
                  <button onClick={() => removeItem(item.id)}
                    style={{ background: 'none', color: 'var(--red)', fontSize: '1rem', padding: '0.25rem', opacity: 0.7, transition: 'opacity var(--transition)' }}
                    onMouseEnter={e => e.target.style.opacity = 1}
                    onMouseLeave={e => e.target.style.opacity = 0.7}
                  >✕</button>
                </div>
              </div>
            ))}
            <button onClick={clearCart} style={{ background: 'none', border: '1px solid var(--border)', color: 'var(--text3)', borderRadius: '6px', padding: '0.5rem 1rem', fontSize: '0.8rem', alignSelf: 'flex-start', transition: 'all var(--transition)' }}
              onMouseEnter={e => { e.target.style.color = 'var(--red)'; e.target.style.borderColor = 'var(--red)'; }}
              onMouseLeave={e => { e.target.style.color = 'var(--text3)'; e.target.style.borderColor = 'var(--border)'; }}
            >Clear Cart</button>
          </div>

          {/* Order Summary */}
          <div className="card" style={{ padding: '1.75rem', position: 'sticky', top: '80px' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.9rem', fontWeight: '700', color: 'var(--cyan)', letterSpacing: '0.05em', marginBottom: '1.5rem' }}>ORDER SUMMARY</div>
            {[
              ['Subtotal', `₹${subtotal.toLocaleString('en-IN')}`],
              ['GST (18%)', `₹${tax.toLocaleString('en-IN')}`],
              ['Shipping', shipping === 0 ? 'FREE' : `₹${shipping}`],
            ].map(([label, val]) => (
              <div key={label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                <span style={{ color: 'var(--text2)', fontSize: '0.85rem' }}>{label}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem', color: val === 'FREE' ? 'var(--green)' : 'var(--text)' }}>{val}</span>
              </div>
            ))}
            <hr style={{ border: 'none', borderTop: '1px solid var(--border)', margin: '1rem 0' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: '700', fontSize: '0.9rem' }}>TOTAL</span>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: '900', fontSize: '1.3rem', color: 'var(--cyan)' }}>₹{total.toLocaleString('en-IN')}</span>
            </div>
            {subtotal < 500 && (
              <div style={{ background: 'rgba(0,212,255,0.06)', border: '1px solid rgba(0,212,255,0.15)', borderRadius: '8px', padding: '0.75rem', fontSize: '0.78rem', color: 'var(--cyan)', marginBottom: '1rem', textAlign: 'center' }}>
                Add ₹{(500 - subtotal).toFixed(0)} more for FREE shipping!
              </div>
            )}
            <button onClick={() => navigate('/checkout')} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '0.9rem', fontSize: '0.9rem' }}>
              Proceed to Checkout →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
