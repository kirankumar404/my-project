import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { wishlistAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function ProductCard({ product }) {
  const { addToCart, loading } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();
  const [wishlisted, setWishlisted] = useState(false);
  const [adding, setAdding] = useState(false);

  const handleAddToCart = async (e) => {
    e.preventDefault();
    if (!user) { toast('Please login to add to cart', 'error'); return; }
    setAdding(true);
    try {
      await addToCart(product.id);
      toast(`${product.name} added to cart!`, 'success');
    } catch (err) {
      toast(err.error || 'Failed to add to cart', 'error');
    } finally {
      setAdding(false);
    }
  };

  const handleWishlist = async (e) => {
    e.preventDefault();
    if (!user) { toast('Please login to wishlist', 'error'); return; }
    try {
      const res = await wishlistAPI.toggle(product.id);
      setWishlisted(res.wishlisted);
      toast(res.wishlisted ? 'Added to wishlist' : 'Removed from wishlist', 'info');
    } catch {}
  };

  const discount = product.discount_percent;
  const inStock = product.stock > 0;

  return (
    <Link to={`/product/${product.slug}`} style={{ display: 'block' }}>
      <div className="card" style={{
        overflow: 'hidden', position: 'relative',
        transition: 'all 0.25s cubic-bezier(0.4,0,0.2,1)',
      }}
        onMouseEnter={e => {
          e.currentTarget.style.borderColor = 'rgba(0,212,255,0.3)';
          e.currentTarget.style.transform = 'translateY(-4px)';
          e.currentTarget.style.boxShadow = '0 20px 40px rgba(0,0,0,0.4), 0 0 20px rgba(0,212,255,0.05)';
        }}
        onMouseLeave={e => {
          e.currentTarget.style.borderColor = 'rgba(99,179,237,0.08)';
          e.currentTarget.style.transform = 'translateY(0)';
          e.currentTarget.style.boxShadow = 'none';
        }}
      >
        {/* Badges */}
        <div style={{ position: 'absolute', top: '0.75rem', left: '0.75rem', zIndex: 2, display: 'flex', gap: '0.4rem' }}>
          {discount > 0 && <span className="badge badge-red">-{discount}%</span>}
          {!inStock && <span className="badge badge-yellow">OUT OF STOCK</span>}
        </div>
        {/* Wishlist */}
        <button onClick={handleWishlist} style={{
          position: 'absolute', top: '0.75rem', right: '0.75rem', zIndex: 2,
          background: 'rgba(8,12,22,0.7)', border: '1px solid var(--border)',
          borderRadius: '50%', width: '32px', height: '32px',
          color: wishlisted ? '#ff4757' : 'var(--text3)',
          fontSize: '0.9rem', backdropFilter: 'blur(8px)',
          transition: 'all var(--transition)',
        }}>
          {wishlisted ? '♥' : '♡'}
        </button>

        {/* Image */}
        <div style={{
          height: '200px', background: 'var(--bg3)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          overflow: 'hidden', borderBottom: '1px solid var(--border)',
        }}>
          <img
            src={product.thumbnail}
            alt={product.name}
            style={{ maxHeight: '180px', maxWidth: '100%', objectFit: 'contain', padding: '1rem', transition: 'transform 0.3s ease' }}
            onMouseEnter={e => e.target.style.transform = 'scale(1.05)'}
            onMouseLeave={e => e.target.style.transform = 'scale(1)'}
            onError={e => e.target.src = 'https://via.placeholder.com/300x200?text=⚡'}
          />
        </div>

        <div style={{ padding: '1rem' }}>
          {/* Category */}
          <div style={{ fontSize: '0.7rem', color: 'var(--cyan)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: '0.4rem' }}>
            {product.category_name} · {product.brand_name || 'Generic'}
          </div>
          {/* Name */}
          <h3 style={{ fontSize: '0.9rem', fontWeight: '600', color: 'var(--text)', marginBottom: '0.6rem', lineHeight: '1.3',
            display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden'
          }}>{product.name}</h3>

          {/* Rating */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.75rem' }}>
            <div className="stars">
              {[1,2,3,4,5].map(s => (
                <span key={s} className={`star ${s <= Math.round(product.average_rating) ? 'filled' : ''}`}>★</span>
              ))}
            </div>
            <span style={{ fontSize: '0.72rem', color: 'var(--text3)', fontFamily: 'var(--font-mono)' }}>
              ({product.review_count})
            </span>
          </div>

          {/* Price & CTA */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: '700', color: 'var(--cyan)' }}>
                ₹{Number(product.discounted_price).toLocaleString('en-IN')}
              </div>
              {discount > 0 && (
                <div style={{ fontSize: '0.75rem', color: 'var(--text3)', textDecoration: 'line-through', fontFamily: 'var(--font-mono)' }}>
                  ₹{Number(product.price).toLocaleString('en-IN')}
                </div>
              )}
            </div>
            <button
              onClick={handleAddToCart}
              disabled={!inStock || adding}
              style={{
                background: inStock ? 'var(--cyan)' : 'var(--surface2)',
                color: inStock ? '#000' : 'var(--text3)',
                border: 'none', borderRadius: '6px',
                padding: '0.5rem 0.9rem', fontSize: '0.78rem', fontWeight: '700',
                transition: 'all var(--transition)',
                opacity: adding ? 0.7 : 1,
              }}
            >
              {adding ? '...' : inStock ? '+ Cart' : 'Sold Out'}
            </button>
          </div>
        </div>
      </div>
    </Link>
  );
}
