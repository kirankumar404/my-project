import { createContext, useContext, useState, useEffect } from 'react';
import { cartAPI } from '../services/api';
import { useAuth } from './AuthContext';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const { user } = useAuth();
  const [cart, setCart] = useState({ items: [], total_items: 0, subtotal: 0 });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) fetchCart();
    else setCart({ items: [], total_items: 0, subtotal: 0 });
  }, [user]);

  const fetchCart = async () => {
    try {
      const data = await cartAPI.get();
      setCart(data);
    } catch {}
  };

  const addToCart = async (productId, quantity = 1) => {
    setLoading(true);
    try {
      const data = await cartAPI.add(productId, quantity);
      setCart(data);
      return true;
    } catch (err) {
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const updateItem = async (itemId, quantity) => {
    const data = await cartAPI.update(itemId, quantity);
    setCart(data);
  };

  const removeItem = async (itemId) => {
    const data = await cartAPI.remove(itemId);
    setCart(data);
  };

  const clearCart = async () => {
    await cartAPI.clear();
    setCart({ items: [], total_items: 0, subtotal: 0 });
  };

  return (
    <CartContext.Provider value={{ cart, loading, addToCart, updateItem, removeItem, clearCart, fetchCart }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
