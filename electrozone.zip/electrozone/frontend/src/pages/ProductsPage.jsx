import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { productsAPI } from '../services/api';
import ProductCard from '../components/ProductCard';

export default function ProductsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [count, setCount] = useState(0);
  const [page, setPage] = useState(1);

  const search = searchParams.get('search') || '';
  const category = searchParams.get('category') || '';
  const brand = searchParams.get('brand') || '';
  const minPrice = searchParams.get('min_price') || '';
  const maxPrice = searchParams.get('max_price') || '';
  const ordering = searchParams.get('ordering') || '-created_at';

  useEffect(() => {
    productsAPI.categories().then(setCategories);
    productsAPI.brands().then(setBrands);
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (category) params.set('category', category);
    if (brand) params.set('brand', brand);
    if (minPrice) params.set('min_price', minPrice);
    if (maxPrice) params.set('max_price', maxPrice);
    if (ordering) params.set('ordering', ordering);
    params.set('page', page);

    if (searchParams.get('featured')) {
      productsAPI.featured().then(data => { setProducts(data); setCount(data.length); setLoading(false); });
    } else if (searchParams.get('deals')) {
      productsAPI.deals().then(data => { setProducts(data); setCount(data.length); setLoading(false); });
    } else {
      productsAPI.list(params.toString()).then(data => {
        setProducts(data.results || data);
        setCount(data.count || (data.results || data).length);
        setLoading(false);
      });
    }
  }, [searchParams, page]);

  const setParam = (key, val) => {
    const p = new URLSearchParams(searchParams);
    if (val) p.set(key, val); else p.delete(key);
    p.delete('page'); setPage(1);
    setSearchParams(p);
  };

  return (
    <div style={{ padding: '2rem 1.5rem' }}>
      <div className="container">
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--cyan)', letterSpacing: '0.1em', marginBottom: '0.4rem' }}>
            // {count} PRODUCTS FOUND
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: '700' }}>
            {search ? `Results: "${search}"` : category ? category.replace(/-/g, ' ').toUpperCase() : 'ALL PRODUCTS'}
          </h1>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: '2rem' }}>
          {/* Sidebar Filters */}
          <aside>
            <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '1.5rem', position: 'sticky', top: '80px' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--cyan)', letterSpacing: '0.1em', marginBottom: '1.5rem' }}>// FILTERS</div>

              {/* Category */}
              <div style={{ marginBottom: '1.5rem' }}>
                <div style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text)', marginBottom: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Category</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                  <button onClick={() => setParam('category', '')}
                    style={{ textAlign: 'left', background: !category ? 'var(--cyan-dim)' : 'none', border: !category ? '1px solid rgba(0,212,255,0.2)' : '1px solid transparent', color: !category ? 'var(--cyan)' : 'var(--text2)', padding: '0.4rem 0.6rem', borderRadius: '6px', fontSize: '0.82rem', cursor: 'pointer' }}>
                    All Categories
                  </button>
                  {categories.map(c => (
                    <button key={c.id} onClick={() => setParam('category', c.slug)}
                      style={{ textAlign: 'left', background: category === c.slug ? 'var(--cyan-dim)' : 'none', border: category === c.slug ? '1px solid rgba(0,212,255,0.2)' : '1px solid transparent', color: category === c.slug ? 'var(--cyan)' : 'var(--text2)', padding: '0.4rem 0.6rem', borderRadius: '6px', fontSize: '0.82rem', cursor: 'pointer' }}>
                      {c.icon} {c.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div style={{ marginBottom: '1.5rem' }}>
                <div style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text)', marginBottom: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Price Range</div>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <input className="input" placeholder="Min" type="number" defaultValue={minPrice}
                    onBlur={e => setParam('min_price', e.target.value)}
                    style={{ fontSize: '0.8rem', padding: '0.5rem 0.6rem' }} />
                  <input className="input" placeholder="Max" type="number" defaultValue={maxPrice}
                    onBlur={e => setParam('max_price', e.target.value)}
                    style={{ fontSize: '0.8rem', padding: '0.5rem 0.6rem' }} />
                </div>
              </div>

              {/* Sort */}
              <div>
                <div style={{ fontSize: '0.8rem', fontWeight: '600', color: 'var(--text)', marginBottom: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Sort By</div>
                <select className="input" value={ordering} onChange={e => setParam('ordering', e.target.value)}
                  style={{ fontSize: '0.82rem', padding: '0.5rem 0.6rem' }}>
                  <option value="-created_at">Newest First</option>
                  <option value="price">Price: Low to High</option>
                  <option value="-price">Price: High to Low</option>
                  <option value="name">Name A-Z</option>
                </select>
              </div>
            </div>
          </aside>

          {/* Products Grid */}
          <div>
            {loading ? (
              <div style={{ display: 'flex', justifyContent: 'center', padding: '5rem' }}>
                <div className="loader" />
              </div>
            ) : products.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '5rem', color: 'var(--text3)' }}>
                <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>⚡</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem', marginBottom: '0.5rem' }}>No Products Found</div>
                <div style={{ fontSize: '0.85rem' }}>Try different filters or search terms</div>
              </div>
            ) : (
              <div className="grid-3">
                {products.map(p => <ProductCard key={p.id} product={p} />)}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
