import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export function LoginPage() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(form);
      toast('Welcome back!', 'success');
      navigate('/');
    } catch (err) {
      toast(err.non_field_errors?.[0] || 'Login failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  return <AuthLayout title="SIGN IN" subtitle="Welcome back to ElectroZone">
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      <div>
        <label style={labelStyle}>Email Address</label>
        <input className="input" type="email" placeholder="you@example.com" required
          value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
      </div>
      <div>
        <label style={labelStyle}>Password</label>
        <input className="input" type="password" placeholder="••••••••" required
          value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
      </div>
      <button type="submit" className="btn btn-primary" disabled={loading}
        style={{ marginTop: '0.5rem', justifyContent: 'center', padding: '0.85rem', fontSize: '0.9rem' }}>
        {loading ? 'Signing in...' : 'Sign In →'}
      </button>
      <p style={{ textAlign: 'center', fontSize: '0.85rem', color: 'var(--text3)' }}>
        Don't have an account? <Link to="/register" style={{ color: 'var(--cyan)' }}>Register</Link>
      </p>
    </form>
  </AuthLayout>;
}

export function RegisterPage() {
  const [form, setForm] = useState({ email: '', first_name: '', last_name: '', phone: '', password: '', password2: '' });
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.password2) { toast('Passwords do not match', 'error'); return; }
    setLoading(true);
    try {
      await register(form);
      toast('Account created!', 'success');
      navigate('/');
    } catch (err) {
      const msg = Object.values(err)[0]?.[0] || 'Registration failed';
      toast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  return <AuthLayout title="CREATE ACCOUNT" subtitle="Join ElectroZone today">
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
        <div>
          <label style={labelStyle}>First Name</label>
          <input className="input" placeholder="Kiran" required value={form.first_name} onChange={e => setForm({ ...form, first_name: e.target.value })} />
        </div>
        <div>
          <label style={labelStyle}>Last Name</label>
          <input className="input" placeholder="Kumar" required value={form.last_name} onChange={e => setForm({ ...form, last_name: e.target.value })} />
        </div>
      </div>
      <div>
        <label style={labelStyle}>Email Address</label>
        <input className="input" type="email" placeholder="you@example.com" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
      </div>
      <div>
        <label style={labelStyle}>Phone Number</label>
        <input className="input" type="tel" placeholder="+91 9999999999" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
      </div>
      <div>
        <label style={labelStyle}>Password</label>
        <input className="input" type="password" placeholder="Min 6 characters" required value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
      </div>
      <div>
        <label style={labelStyle}>Confirm Password</label>
        <input className="input" type="password" placeholder="Repeat password" required value={form.password2} onChange={e => setForm({ ...form, password2: e.target.value })} />
      </div>
      <button type="submit" className="btn btn-primary" disabled={loading}
        style={{ marginTop: '0.5rem', justifyContent: 'center', padding: '0.85rem', fontSize: '0.9rem' }}>
        {loading ? 'Creating account...' : 'Create Account →'}
      </button>
      <p style={{ textAlign: 'center', fontSize: '0.85rem', color: 'var(--text3)' }}>
        Already have an account? <Link to="/login" style={{ color: 'var(--cyan)' }}>Sign In</Link>
      </p>
    </form>
  </AuthLayout>;
}

const labelStyle = {
  display: 'block', fontSize: '0.75rem', fontWeight: '600',
  color: 'var(--text2)', marginBottom: '0.4rem',
  textTransform: 'uppercase', letterSpacing: '0.05em',
  fontFamily: 'var(--font-mono)',
};

function AuthLayout({ title, subtitle, children }) {
  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)', padding: '2rem',
      backgroundImage: `linear-gradient(rgba(0,212,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,255,0.02) 1px, transparent 1px)`,
      backgroundSize: '40px 40px',
    }}>
      <div style={{
        background: 'var(--surface)', border: '1px solid var(--border2)',
        borderRadius: '16px', padding: '3rem', width: '100%', maxWidth: '440px',
        boxShadow: '0 0 60px rgba(0,212,255,0.05)',
        animation: 'slideUp 0.4s ease',
      }}>
        <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: '900', color: 'var(--cyan)', letterSpacing: '0.1em', marginBottom: '0.5rem' }}>
            ELECTRO<span style={{ color: 'var(--text)' }}>ZONE</span>
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: '700', letterSpacing: '0.05em', marginBottom: '0.3rem' }}>{title}</h1>
          <p style={{ color: 'var(--text3)', fontSize: '0.85rem' }}>{subtitle}</p>
        </div>
        {children}
      </div>
    </div>
  );
}
