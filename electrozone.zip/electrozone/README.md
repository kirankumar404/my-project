# ⚡ ElectroZone — Full-Stack Electronics E-Commerce

A premium electronics e-commerce platform built with **Django REST API** backend and **React JS** frontend, powered by **MySQL**.

---

## 🏗️ Architecture

```
electrozone/
├── backend/          # Django REST API
│   ├── accounts/     # Custom User Auth (JWT)
│   ├── products/     # Products, Categories, Brands, Wishlist, Reviews
│   ├── cart/         # Cart & Cart Items
│   ├── orders/       # Orders & Order Items
│   └── electrozone/  # Django settings & URLs
│
└── frontend/         # React JS SPA (Vite)
    └── src/
        ├── components/   # Navbar, ProductCard, Footer
        ├── context/      # Auth, Cart, Toast contexts
        ├── pages/        # Home, Products, Cart, Checkout, Orders, Auth
        └── services/     # API service layer (JWT auto-refresh)
```

---

## ✨ Unique Features

- 🔐 **JWT Auth** with auto token refresh
- 🛒 **Persistent Cart** tied to user account
- ❤️ **Wishlist** toggle (per user)
- ⭐ **Product Reviews** with star ratings
- 🔍 **Advanced Filtering** — category, brand, price range, search
- 💸 **GST Calculation** (18%) + free shipping over ₹500
- 📦 **Order Tracking** with status colors
- 🌙 **Dark Cyberpunk UI** with scanline overlay + grid background
- 📱 Fully **responsive** layout

---

## 🚀 Setup

### 1. MySQL Database

```sql
CREATE DATABASE electrozone_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'electrozone'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON electrozone_db.* TO 'electrozone'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Create .env file
cat > .env << EOF
SECRET_KEY=your-secret-key-here-change-this
DEBUG=True
DB_NAME=electrozone_db
DB_USER=electrozone
DB_PASSWORD=your_password
DB_HOST=localhost
DB_PORT=3306
EOF

# Create Django project structure (if starting fresh)
django-admin startproject electrozone .
python manage.py startapp accounts
python manage.py startapp products
python manage.py startapp cart
python manage.py startapp orders

# Run migrations
python manage.py makemigrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Load sample data (optional)
python manage.py loaddata fixtures/sample_data.json

# Start server
python manage.py runserver
```

Backend runs at: http://localhost:8000
Admin panel: http://localhost:8000/admin

### 3. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

Frontend runs at: http://localhost:3000

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register/` | Register new user |
| POST | `/api/auth/login/` | Login (returns JWT) |
| POST | `/api/auth/logout/` | Logout (blacklist token) |
| GET/PATCH | `/api/auth/profile/` | View/update profile |
| GET | `/api/products/` | List products (search, filter, sort) |
| GET | `/api/products/{slug}/` | Product detail |
| GET | `/api/products/featured/` | Featured products |
| GET | `/api/products/deals/` | Discount deals |
| POST | `/api/products/{slug}/review/` | Add review |
| GET | `/api/products/categories/` | All categories |
| GET | `/api/products/brands/` | All brands |
| GET/POST | `/api/products/wishlist/` | List/toggle wishlist |
| GET | `/api/cart/` | Get cart |
| POST | `/api/cart/add/` | Add to cart |
| PATCH | `/api/cart/item/{id}/update/` | Update quantity |
| DELETE | `/api/cart/item/{id}/remove/` | Remove item |
| GET | `/api/orders/` | List orders |
| POST | `/api/orders/place/` | Place order |

---

## 🎨 Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.11+, Django 4.2, DRF |
| Auth | JWT (SimpleJWT) with auto-refresh |
| Database | MySQL 8.0 |
| Frontend | React 18, Vite, React Router v6 |
| Fonts | Orbitron (display), Space Grotesk (body), JetBrains Mono |
| Styling | Pure CSS with CSS Variables, no UI framework |

---

## 🛒 Adding Sample Products via Admin

1. Go to http://localhost:8000/admin
2. Login with your superuser credentials
3. Add Categories (e.g. Smartphones, Laptops, Audio, Smart Home)
4. Add Brands (e.g. Apple, Samsung, Sony)
5. Add Products with images and specifications JSON

Example specifications JSON:
```json
{
  "Display": "6.7\" AMOLED 120Hz",
  "Processor": "Snapdragon 8 Gen 3",
  "RAM": "12GB",
  "Storage": "256GB",
  "Battery": "5000 mAh",
  "Camera": "200MP + 12MP + 10MP"
}
```

---

Built with ⚡ by Enupothula Kiran Kumar
