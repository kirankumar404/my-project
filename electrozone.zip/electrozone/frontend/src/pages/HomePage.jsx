import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { productsAPI } from '../services/api';
import ProductCard from '../components/ProductCard';

export default function HomePage() {
  const [featured, setFeatured] = useState([]);
  const [deals, setDeals] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      productsAPI.featured(),
      productsAPI.deals(),
      productsAPI.categories(),
    ]).then(([f, d, c]) => {
      setFeatured(f); setDeals(d); setCategories(c);
    }).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      {/* ── HERO ── */}
      <section style={{
        minHeight: '85vh', display: 'flex', alignItems: 'center',
        background: 'linear-gradient(135deg, #050810 0%, #0a0f1e 50%, #050810 100%)',
        position: 'relative', overflow: 'hidden',
        padding: '4rem 1.5rem',
      }}>
        {/* Animated grid bg */}
        <div style={{
          position: 'absolute', inset: 0, zIndex: 0,
          backgroundImage: `
            linear-gradient(rgba(0,212,255,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,212,255,0.03) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
        }} />
        {/* Glow orbs */}
        <div style={{ position: 'absolute', top: '10%', right: '15%', width: '400px', height: '400px', background: 'radial-gradient(circle, rgba(0,212,255,0.08) 0%, transparent 70%)', borderRadius: '50%', zIndex: 0 }} />
        <div style={{ position: 'absolute', bottom: '20%', left: '5%', width: '300px', height: '300px', background: 'radial-gradient(circle, rgba(14,165,233,0.06) 0%, transparent 70%)', borderRadius: '50%', zIndex: 0 }} />

        <div className="container" style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ maxWidth: '700px', animation: 'slideUp 0.7s ease' }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
              background: 'var(--cyan-dim)', border: '1px solid rgba(0,212,255,0.2)',
              borderRadius: '4px', padding: '0.3rem 0.8rem',
              fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--cyan)',
              letterSpacing: '0.1em', marginBottom: '1.5rem',
            }}>
              <span style={{ animation: 'pulse 2s infinite', display: 'inline-block', width: '6px', height: '6px', borderRadius: '50%', background: 'var(--cyan)' }} />
              NEXT-GEN ELECTRONICS STORE
            </div>
            <h1 style={{
              fontFamily: 'var(--font-display)', fontSize: 'clamp(2.5rem,6vw,5rem)',
              fontWeight: '900', lineHeight: '1', letterSpacing: '-0.02em',
              marginBottom: '1.5rem',
            }}>
              <span style={{ display: 'block' }}>POWER YOUR</span>
              <span className="animate-glitch glow" style={{ display: 'block' }}>WORLD</span>
              <span style={{ display: 'block', fontSize: '0.5em', color: 'var(--text2)', fontWeight: '400', fontFamily: 'var(--font-body)', letterSpacing: 'normal' }}>
                Premium electronics, delivered fast
              </span>
            </h1>
            <p style={{ color: 'var(--text2)', fontSize: '1.05rem', maxWidth: '500px', marginBottom: '2.5rem', lineHeight: '1.7', fontWeight: '300' }}>
              Discover the latest smartphones, laptops, audio gear, and smart home devices. Built for those who demand the best.
            </p>
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              <Link to="/products" className="btn btn-primary" style={{ fontSize: '0.9rem', padding: '0.85rem 2rem' }}>
                Shop Now →
              </Link>
              <Link to="/products?deals=true" className="btn btn-outline" style={{ fontSize: '0.9rem', padding: '0.85rem 2rem' }}>
                View Deals
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── CATEGORIES ── */}
      <section style={{ padding: '5rem 1.5rem', background: 'var(--bg2)' }}>
        <div className="container">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2.5rem' }}>
            <div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--cyan)', letterSpacing: '0.1em', marginBottom: '0.5rem' }}>// BROWSE</div>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: '700' }}>Categories</h2>
            </div>
            <Link to="/products" style={{ color: 'var(--cyan)', fontSize: '0.85rem', fontFamily: 'var(--font-mono)' }}>View All →</Link>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: '1rem' }}>
            {categories.map(cat => (
              <Link key={cat.id} to={`/products?category=${cat.slug}`}
                style={{
                  background: 'var(--surface)', border: '1px solid var(--border)',
                  borderRadius: '12px', padding: '1.5rem 1rem',
                  textAlign: 'center', transition: 'all var(--transition)',
                  display: 'block',
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--cyan)'; e.currentTarget.style.background = 'var(--cyan-dim)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.background = 'var(--surface)'; }}
              >
                <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>{cat.icon || '📱'}</div>
                <div style={{ fontSize: '0.82rem', fontWeight: '600', color: 'var(--text)', marginBottom: '0.2rem' }}>{cat.name}</div>
                <div style={{ fontSize: '0.7rem', color: 'var(--text3)', fontFamily: 'var(--font-mono)' }}>{cat.product_count} items</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED ── */}
      {featured.length > 0 && (
        <section style={{ padding: '5rem 1.5rem' }}>
          <div className="container">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2.5rem' }}>
              <div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--cyan)', letterSpacing: '0.1em', marginBottom: '0.5rem' }}>// HANDPICKED</div>
                <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: '700' }}>Featured Products</h2>
              </div>
              <Link to="/products?featured=true" style={{ color: 'var(--cyan)', fontSize: '0.85rem', fontFamily: 'var(--font-mono)' }}>View All →</Link>
            </div>
            <div className="grid-4">
              {featured.slice(0, 8).map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        </section>
      )}

      {/* ── DEALS ── */}
      {deals.length > 0 && (
        <section style={{ padding: '5rem 1.5rem', background: 'var(--bg2)' }}>
          <div className="container">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '2.5rem' }}>
              <div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--red)', letterSpacing: '0.1em', marginBottom: '0.5rem' }}>// LIMITED TIME</div>
                <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: '700' }}>🔥 Hot Deals</h2>
              </div>
              <Link to="/products?deals=true" style={{ color: 'var(--cyan)', fontSize: '0.85rem', fontFamily: 'var(--font-mono)' }}>View All →</Link>
            </div>
            <div className="grid-4">
              {deals.slice(0, 4).map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        </section>
      )}

      {/* ── USP Banner ── */}
      <section style={{ padding: '4rem 1.5rem', borderTop: '1px solid var(--border)' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '2rem' }}>
            {[
              ['⚡', 'Fast Delivery', 'Get your orders in 2-3 business days'],
              ['🔒', 'Secure Payments', 'UPI, Cards, COD — all secured'],
              ['↩', 'Easy Returns', '7-day hassle-free return policy'],
              ['🎧', '24/7 Support', 'Our team is always here for you'],
            ].map(([icon, title, desc]) => (
              <div key={title} style={{ textAlign: 'center', padding: '2rem 1rem' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>{icon}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.85rem', fontWeight: '700', color: 'var(--cyan)', marginBottom: '0.4rem', letterSpacing: '0.05em' }}>{title}</div>
                <div style={{ fontSize: '0.82rem', color: 'var(--text3)' }}>{desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
