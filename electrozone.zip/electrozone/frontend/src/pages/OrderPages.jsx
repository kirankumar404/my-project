import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ordersAPI } from '../services/api';

export function CheckoutPage() {
  const { cart, clearCart } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    shipping_name: user?.full_name || '',
    shipping_email: user?.email || '',
    shipping_phone: user?.phone || '',
    shipping_address: user?.address || '',
    shipping_city: user?.city || '',
    shipping_state: user?.state || '',
    shipping_pincode: user?.pincode || '',
    payment_method: 'cod',
    notes: '',
  });

  const subtotal = Number(cart.subtotal || 0);
  const tax = Math.round(subtotal * 0.18);
  const shipping = subtotal >= 500 ? 0 : 49;
  const total = subtotal + tax + shipping;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const order = await ordersAPI.place(form);
      toast('Order placed successfully! 🎉', 'success');
      navigate(`/orders`);
    } catch (err) {
      toast(err.error || 'Failed to place order', 'error');
    } finally {
      setLoading(false);
    }
  };

  const inputStyle = { marginBottom: '0' };

  return (
    <div style={{ padding: '2.5rem 1.5rem' }}>
      <div className="container">
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--cyan)', marginBottom: '0.5rem' }}>// CHECKOUT</div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: '700', marginBottom: '2rem' }}>Complete Order</h1>
        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '2rem', alignItems: 'start' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* Shipping */}
              <div className="card" style={{ padding: '1.75rem' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.85rem', fontWeight: '700', color: 'var(--cyan)', marginBottom: '1.25rem', letterSpacing: '0.05em' }}>SHIPPING INFO</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  {[
                    ['shipping_name', 'Full Name', 'text', 'Kiran Kumar'],
                    ['shipping_email', 'Email', 'email', 'you@example.com'],
                    ['shipping_phone', 'Phone', 'tel', '+91 9999999999'],
                    ['shipping_pincode', 'Pincode', 'text', '500001'],
                    ['shipping_city', 'City', 'text', 'Hyderabad'],
                    ['shipping_state', 'State', 'text', 'Telangana'],
                  ].map(([key, label, type, ph]) => (
                    <div key={key}>
                      <label style={{ display: 'block', fontSize: '0.72rem', color: 'var(--text2)', marginBottom: '0.4rem', textTransform: 'uppercase', letterSpacing: '0.05em', fontFamily: 'var(--font-mono)' }}>{label}</label>
                      <input className="input" type={type} placeholder={ph} required value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} />
                    </div>
                  ))}
                </div>
                <div style={{ marginTop: '1rem' }}>
                  <label style={{ display: 'block', fontSize: '0.72rem', color: 'var(--text2)', marginBottom: '0.4rem', textTransform: 'uppercase', letterSpacing: '0.05em', fontFamily: 'var(--font-mono)' }}>Address</label>
                  <textarea className="input" placeholder="Street address, apartment..." required rows={3}
                    value={form.shipping_address} onChange={e => setForm({ ...form, shipping_address: e.target.value })} style={{ resize: 'vertical' }} />
                </div>
              </div>

              {/* Payment */}
              <div className="card" style={{ padding: '1.75rem' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.85rem', fontWeight: '700', color: 'var(--cyan)', marginBottom: '1.25rem', letterSpacing: '0.05em' }}>PAYMENT METHOD</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                  {[['cod', '💵 Cash on Delivery'], ['upi', '📱 UPI Payment'], ['card', '💳 Credit / Debit Card']].map(([val, label]) => (
                    <label key={val} style={{
                      display: 'flex', alignItems: 'center', gap: '0.75rem',
                      padding: '1rem', borderRadius: '8px', cursor: 'pointer',
                      border: `1px solid ${form.payment_method === val ? 'rgba(0,212,255,0.4)' : 'var(--border)'}`,
                      background: form.payment_method === val ? 'var(--cyan-dim)' : 'transparent',
                      transition: 'all var(--transition)',
                    }}>
                      <input type="radio" name="payment" value={val} checked={form.payment_method === val}
                        onChange={() => setForm({ ...form, payment_method: val })} style={{ accentColor: 'var(--cyan)' }} />
                      <span style={{ fontSize: '0.9rem', fontWeight: form.payment_method === val ? '600' : '400' }}>{label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            {/* Summary */}
            <div className="card" style={{ padding: '1.75rem', position: 'sticky', top: '80px' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '0.9rem', fontWeight: '700', color: 'var(--cyan)', letterSpacing: '0.05em', marginBottom: '1.25rem' }}>ORDER SUMMARY</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1rem', maxHeight: '250px', overflowY: 'auto' }}>
                {cart.items.map(item => (
                  <div key={item.id} style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
                    <img src={item.product.thumbnail} alt="" style={{ width: '48px', height: '48px', objectFit: 'contain', background: 'var(--bg)', borderRadius: '6px', padding: '4px' }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text)', fontWeight: '500', lineHeight: '1.2', display: '-webkit-box', WebkitLineClamp: 1, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{item.product.name}</div>
                      <div style={{ fontSize: '0.72rem', color: 'var(--text3)', fontFamily: 'var(--font-mono)' }}>x{item.quantity}</div>
                    </div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.82rem', color: 'var(--text)' }}>₹{Number(item.line_total).toLocaleString('en-IN')}</div>
                  </div>
                ))}
              </div>
              <hr style={{ border: 'none', borderTop: '1px solid var(--border)', margin: '1rem 0' }} />
              {[['Subtotal', `₹${subtotal.toLocaleString('en-IN')}`], ['GST (18%)', `₹${tax.toLocaleString('en-IN')}`], ['Shipping', shipping === 0 ? 'FREE' : `₹${shipping}`]].map(([l, v]) => (
                <div key={l} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.6rem' }}>
                  <span style={{ color: 'var(--text2)', fontSize: '0.85rem' }}>{l}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem', color: v === 'FREE' ? 'var(--green)' : 'var(--text)' }}>{v}</span>
                </div>
              ))}
              <hr style={{ border: 'none', borderTop: '1px solid var(--border)', margin: '1rem 0' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: '700', fontSize: '0.9rem' }}>TOTAL</span>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: '900', fontSize: '1.3rem', color: 'var(--cyan)' }}>₹{total.toLocaleString('en-IN')}</span>
              </div>
              <button type="submit" className="btn btn-primary" disabled={loading}
                style={{ width: '100%', justifyContent: 'center', padding: '0.9rem', fontSize: '0.9rem' }}>
                {loading ? 'Placing Order...' : `Place Order ₹${total.toLocaleString('en-IN')} →`}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export function OrdersPage() {
  const [orders, setOrders] = useState(null);
  const { user } = useAuth();
  const navigate = useNavigate();

  useState(() => {
    if (user) ordersAPI.list().then(d => setOrders(d.results || d));
  }, [user]);

  const statusColors = { pending: 'var(--yellow)', confirmed: 'var(--cyan)', processing: 'var(--cyan)', shipped: '#a78bfa', delivered: 'var(--green)', cancelled: 'var(--red)' };

  if (!user) return <div style={{ textAlign: 'center', padding: '5rem' }}><Link to="/login" className="btn btn-primary">Login to View Orders</Link></div>;
  if (!orders) return <div style={{ display: 'flex', justifyContent: 'center', padding: '5rem' }}><div className="loader" /></div>;

  return (
    <div style={{ padding: '2.5rem 1.5rem' }}>
      <div className="container">
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--cyan)', marginBottom: '0.5rem' }}>// ORDER HISTORY</div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '2rem', fontWeight: '700', marginBottom: '2rem' }}>My Orders</h1>
        {orders.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '5rem', color: 'var(--text3)' }}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📦</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem', marginBottom: '1rem' }}>No orders yet</div>
            <Link to="/products" className="btn btn-primary">Start Shopping</Link>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            {orders.map(order => (
              <div key={order.id} className="card" style={{ padding: '1.5rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.75rem' }}>
                  <div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text3)', marginBottom: '0.2rem' }}>ORDER ID</div>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: '700', color: 'var(--cyan)' }}>#{order.order_id_short}</div>
                    <div style={{ fontSize: '0.78rem', color: 'var(--text3)', marginTop: '0.2rem' }}>{new Date(order.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</div>
                  </div>
                  <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', padding: '0.3rem 0.75rem', borderRadius: '4px', background: `${statusColors[order.status]}15`, color: statusColors[order.status], border: `1px solid ${statusColors[order.status]}30`, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                      {order.status}
                    </span>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: '700', color: 'var(--text)' }}>
                      ₹{Number(order.total).toLocaleString('en-IN')}
                    </div>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
                  {order.items.slice(0, 3).map((item, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: '6px', padding: '0.4rem 0.7rem' }}>
                      <span style={{ fontSize: '0.78rem', color: 'var(--text2)' }}>{item.product_name}</span>
                      <span className="badge badge-cyan">x{item.quantity}</span>
                    </div>
                  ))}
                  {order.items.length > 3 && <span style={{ fontSize: '0.78rem', color: 'var(--text3)', padding: '0.4rem' }}>+{order.items.length - 3} more</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
