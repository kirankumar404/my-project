import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer style={{
      background: 'var(--bg2)',
      borderTop: '1px solid var(--border)',
      padding: '3rem 1.5rem 1.5rem',
      marginTop: 'auto',
    }}>
      <div className="container">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '2.5rem', marginBottom: '2.5rem' }}>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: '900', color: 'var(--cyan)', letterSpacing: '0.1em', marginBottom: '0.75rem' }}>
              ELECTRO<span style={{ color: 'var(--text)' }}>ZONE</span>
            </div>
            <p style={{ fontSize: '0.82rem', color: 'var(--text3)', lineHeight: '1.65' }}>
              Next-gen electronics for those who demand the best. Quality gear, fast delivery.
            </p>
          </div>
          {[
            ['Shop', [['/products', 'All Products'], ['/products?featured=true', 'Featured'], ['/products?deals=true', 'Deals']]],
            ['Account', [['/login', 'Sign In'], ['/register', 'Register'], ['/orders', 'My Orders'], ['/cart', 'Cart']]],
            ['Support', [['#', 'Help Center'], ['#', 'Returns'], ['#', 'Track Order'], ['#', 'Contact Us']]],
          ].map(([title, links]) => (
            <div key={title}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--cyan)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '1rem' }}>{title}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {links.map(([href, label]) => (
                  <Link key={label} to={href} style={{ fontSize: '0.85rem', color: 'var(--text3)', transition: 'color var(--transition)' }}
                    onMouseEnter={e => e.target.style.color = 'var(--cyan)'}
                    onMouseLeave={e => e.target.style.color = 'var(--text3)'}
                  >{label}</Link>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <span style={{ fontSize: '0.78rem', color: 'var(--text3)', fontFamily: 'var(--font-mono)' }}>© 2024 ElectroZone · Built with Python + React</span>
          <div style={{ display: 'flex', gap: '1rem' }}>
            {['Privacy', 'Terms', 'Sitemap'].map(l => (
              <Link key={l} to="#" style={{ fontSize: '0.75rem', color: 'var(--text3)' }}>{l}</Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
